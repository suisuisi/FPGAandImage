# FPGA_SOBLE_OV7670
FPGA_SOBLE_OV7670
This is V1.0 and i will upload 

See：https://blog.csdn.net/Pieces_thinking/article/details/83150325
